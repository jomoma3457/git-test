import "./styles.css";
import StopWatch from "./Components/StopWatch";

export default function App() {
  return (
    <div className="App">
      <StopWatch />
    </div>
  );
}
