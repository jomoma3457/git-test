# RandomQuoteMachine

A Pen created on CodePen.io. Original URL: [https://codepen.io/jomoma3457/pen/GRwRzWb](https://codepen.io/jomoma3457/pen/GRwRzWb).

Random Quote Machine for freeCodeCamp project