import React from "react";
import "./Components/Main.css";
import Main from "./Components/Main";

export default function BookFinder() {
  return (
    <div className="App">
      <Main />
    </div>
  );
}
